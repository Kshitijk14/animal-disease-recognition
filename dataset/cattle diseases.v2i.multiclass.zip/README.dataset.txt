# cattle diseases > 2023-07-27 10:35pm
https://universe.roboflow.com/sliit-kuemd/cattle-diseases

Provided by a Roboflow user
License: CC BY 4.0

